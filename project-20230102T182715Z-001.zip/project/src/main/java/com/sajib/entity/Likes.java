package com.sajib.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by USER on 12/03/2020.
 */
@Entity
public class Likes {

    @Id
    private long id;
    private long movieId;
    private long viewerId;


}
