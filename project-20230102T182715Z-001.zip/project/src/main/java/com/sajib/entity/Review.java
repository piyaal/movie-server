package com.sajib.entity;

import lombok.*;

import javax.persistence.*;

/**
 * Created by USER on 12/03/2020.
 */
@NoArgsConstructor
@ToString
@Entity
public class Review {

    @Id
    @SequenceGenerator(name = "review_sequence", sequenceName = "review_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "review_sequence")
    private long id;
    @ManyToOne(targetEntity = AppUser.class, cascade = {CascadeType.MERGE})
    @JoinColumn(name = "appUserId")
    private AppUser appUser;
    private String description;
    private String date;
    private int rating;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public AppUser getAppUser() {
        appUser.setPassword(null);
        return appUser;
    }

    public void setAppUser(AppUser appUser) {
        this.appUser = appUser;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
