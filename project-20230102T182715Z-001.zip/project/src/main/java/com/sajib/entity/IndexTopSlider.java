package com.sajib.entity;

import javax.persistence.*;

/**
 * Created by USER on 13/03/2020.
 */
@Entity
public class IndexTopSlider {

    @Id
    @SequenceGenerator(name = "index_top_slider_sequence", sequenceName = "index_top_slider_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "index_top_slider_sequence")
    private long id;
    @Column(length = 500)
    private String image;

    public IndexTopSlider() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "IndexTopSlider{" +
                "id=" + id +
                ", image='" + image + '\'' +
                '}';
    }
}
