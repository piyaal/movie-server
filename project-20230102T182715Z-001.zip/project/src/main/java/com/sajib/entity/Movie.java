package com.sajib.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Arrays;
import java.util.List;

/**
 * Created by USER on 12/03/2020.
 */
@Entity
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Movie {

    @Id
    @SequenceGenerator(name = "movie_sequence", sequenceName = "movie_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "movie_sequence")
    private long id;
    private String name;
    @Column(length = 1000)
    private String image;
    private String video;
    private String director;
    private String writers;
    private String cast;
    private String plot;
    @Column(length = 1000)
    private String trailer;
    private String category;
    private String budget;
    private String language;
    private String releaseDate;
    private long views;

    @OneToMany(targetEntity = Review.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "movieId", referencedColumnName = "id")
    private List<Review> reviews;
    //@OneToMany
    //private List<Likes> likes;
    @Transient
    private List<String> trailers;

    public List<String> getTrailers() {
        String[] links = trailer.split(",");
        trailers = Arrays.asList(links);
        return trailers;
    }

    public void setTrailers(List<String> trailers) {
        this.trailers = trailers;
    }
}
