package com.sajib.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by USER on 14/03/2020.
 */
@Controller
public class RealityShowController {

    @RequestMapping("/reality-show")
    private String loadRealityShowPage(){
        return "reality-show";
    }

}
