package com.sajib.controller;

import com.sajib.data.CommonDataSet;
import com.sajib.entity.Movie;
import com.sajib.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.List;

/**
 * Created by USER on 12/03/2020.
 */
@Controller
public class MovieController {

    @Autowired
    private CommonDataSet commonDataSet;
    @Autowired
    private MovieRepository movieRepository;

    @RequestMapping("/movie-details")
    private String movieDetails(Principal principal, Model model, @RequestParam long mid)
    {

        commonDataSet.setLoginUser(principal, model);

        System.out.println("# "+mid);

        Movie movie = movieRepository.findById(mid).get();
        System.out.println("# "+movie.toString());
        model.addAttribute("movie", movie);

        return "movies-detail";
    }


    @RequestMapping({"/movies","/movie-collection"})
    private String fetchMovies(Principal principal, Model model)
    {
        commonDataSet.setLoginUser(principal, model);
        Page<Movie> moviePage = movieRepository.findMoviesByCustomSearch(PageRequest.of(0,20));
        model.addAttribute("moviePage", moviePage);
        return "movies";
    }


    @ResponseBody
    @RequestMapping({"/movies2","/movie-collection2"})
    private Page<Movie> fetchMoviesWithRest()
    {
        Page<Movie> movies = movieRepository.findMoviesByCustomSearch(PageRequest.of(0,5));
        return movies;
    }



}
