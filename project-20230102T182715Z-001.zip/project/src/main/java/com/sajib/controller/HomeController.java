package com.sajib.controller;

import com.sajib.data.CommonDataSet;
import com.sajib.entity.IndexTopSlider;
import com.sajib.entity.Movie;
import com.sajib.repository.IndexTopSliderRepository;
import com.sajib.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;
import java.util.List;

/**
 * Created by USER on 11/03/2020.
 */
@Controller
public class HomeController {

    @Autowired
    private CommonDataSet commonDataSet;
    @Autowired
    private IndexTopSliderRepository indexTopSliderRepository;



    @Autowired
    private MovieRepository movieRepository;

    @RequestMapping({"/","/home"})
    private String loadHomePage(Principal principal, Model model){

        commonDataSet.setLoginUser(principal, model);

        /*
        @ Fetch index top slider
         */
        List<IndexTopSlider> indexTopSliders = null;
        try{
            indexTopSliders = indexTopSliderRepository.find10IndexTopSlidersById();
        }catch (Exception ex){
            ex.printStackTrace();
        }

        /*
        @ Fetch movies
         */
        List<Movie> movies = null;
        try {
            movies = movieRepository.fetchTopFourMovies();
        }catch (Exception e){
            e.printStackTrace();
        }

        model.addAttribute("indexTopSliders", indexTopSliders);
        model.addAttribute("movies", movies);

        return "index";
    }



}
