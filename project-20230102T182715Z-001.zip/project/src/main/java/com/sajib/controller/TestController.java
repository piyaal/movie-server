package com.sajib.controller;

import com.sajib.entity.AppUser;
import com.sajib.entity.Movie;
import com.sajib.entity.Review;
import com.sajib.repository.AppUserRepository;
import com.sajib.repository.MovieRepository;
import com.sajib.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by USER on 12/03/2020.
 */
@RestController
public class TestController {

    @Autowired
    private AppUserRepository appUserRepository;
    @Autowired
    private MovieRepository movieRepository;
    @Autowired
    private ReviewRepository reviewRepository;

    @RequestMapping("/fetch-review")
    private List<Review> findReview(@RequestParam(defaultValue = "0") long id)
    {
        List<Review> reviews = null;

        if(id==0){
            reviews = (List<Review>) reviewRepository.findAll();
        }else{
            reviews = new ArrayList<>();
            reviews.add(reviewRepository.findById(id).get());
        }
        return reviews;
    }

    @RequestMapping("/fetch-movies")
    private List<Movie> findMovie(@RequestParam(defaultValue = "0") long id)
    {
        List<Movie> movies = null;
        try{
            movies = (List<Movie>) movieRepository.findAll();
        }catch (Exception e){
           movies = new ArrayList<>();
           movies.add(movieRepository.findById(id).get());
        }
        return movies;
    }



    @RequestMapping("random-parameter-test")
    private String randomParameterTest(@RequestParam("id") int id, @RequestParam("name") String name,
                                       @RequestParam("gpa") float gpa)
    {
        return "Id : "+id+", Name : "+name+", GPA : "+gpa;
    }


}
