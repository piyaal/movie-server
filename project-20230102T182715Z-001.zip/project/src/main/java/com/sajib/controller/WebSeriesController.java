package com.sajib.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by USER on 14/03/2020.
 */
@Controller
public class WebSeriesController {

    @RequestMapping("/web-series")
    private String loadWebSeriesPage(){
        return "web-series";
    }

}
