package com.sajib.controller;

import com.sajib.entity.AppUser;
import com.sajib.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Created by USER on 11/03/2020.
 */
@Controller
public class AccountController {

    @Autowired
    private AppUserRepository appUserRepository;


    @RequestMapping(value = "/login")
    private String loadLoginPage()
    {
       return "login";
    }

    @RequestMapping("/registration-page")
    private String loadRegistrationPage() {
        return "register";
    }

    @RequestMapping("/registration")
    private String userRegistration(@ModelAttribute AppUser appUser, Model model)
    {
        try{
            if(appUserRepository.countAppUserByEmail(appUser.getEmail())==0){
                appUser.setRole(AppUser.USER);
                appUserRepository.save(appUser);
            }else{
                model.addAttribute("error","Email already exist.");
            }
        }catch (Exception e){
            e.printStackTrace();
            model.addAttribute("error","Server error! Please try again later.");
        }
        return "register";
    }

}
