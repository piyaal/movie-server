package com.sajib.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by USER on 14/03/2020.
 */
@Controller
public class CelebrityController {

    @RequestMapping("/celebrity")
    private String loadCelebrityPage(){
        return "celebrity";
    }
}
