package com.sajib.service;

import com.sajib.entity.AppUser;
import com.sajib.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * Created by USER on 11/03/2020.
 */
@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private AppUserRepository appUserRepository;


    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        AppUser appUser = appUserRepository.findAppUsersByEmail(email);
        if(appUser==null)
            throw new UsernameNotFoundException("User not found by email");

        return new MyUserDetails(appUser);
    }
}
