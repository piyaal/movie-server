package com.sajib.repository;

import com.sajib.entity.IndexTopSlider;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by USER on 13/03/2020.
 */
@Transactional
public interface IndexTopSliderRepository extends CrudRepository<IndexTopSlider,Long> {

    @Query(value = "select * from index_top_slider order by id desc limit 10", nativeQuery = true)
    List<IndexTopSlider> find10IndexTopSlidersById();

}
