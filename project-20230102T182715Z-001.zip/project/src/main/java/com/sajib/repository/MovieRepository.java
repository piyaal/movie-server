package com.sajib.repository;

import com.sajib.entity.Movie;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by USER on 12/03/2020.
 */
@Transactional
public interface MovieRepository extends CrudRepository<Movie, Long> {

    @Query(value = "select * from Movie order by id desc LIMIT 4", nativeQuery = true)
    List<Movie> fetchTopFourMovies();

    //List<Movie> findFirst1ByUsernameOrderByIdDesc();
   // List<Movie> findMoviesByIdOrderByIdDesc();

    @Query("select m from Movie m")
    Page<Movie> findMoviesByCustomSearch(Pageable pageable);

}
