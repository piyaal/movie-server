package com.sajib.repository;

import com.sajib.entity.AppUser;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by USER on 11/03/2020.
 */
public interface AppUserRepository extends CrudRepository<AppUser, String> {

    AppUser findAppUsersByEmail(String email);

    int countAppUserByEmail(String email);

}
