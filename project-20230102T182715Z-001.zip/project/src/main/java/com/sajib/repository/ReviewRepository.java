package com.sajib.repository;

import com.sajib.entity.Review;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by USER on 12/03/2020.
 */
public interface ReviewRepository extends CrudRepository<Review, Long> {
}
