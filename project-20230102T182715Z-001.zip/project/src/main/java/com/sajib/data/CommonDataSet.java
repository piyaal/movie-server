package com.sajib.data;

import com.sajib.repository.AppUserRepository;
import com.sajib.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import java.security.Principal;

/**
 * Created by USER on 13/03/2020.
 */
@Component
public class CommonDataSet {

    @Autowired
    private AppUserRepository appUserRepository;

    @Autowired
    private MovieRepository  movieRepository;

    public void setLoginUser(Principal principal, Model model){
          model.addAttribute("app_user", principal==null? null : appUserRepository.findAppUsersByEmail(principal.getName()));
    }



}
