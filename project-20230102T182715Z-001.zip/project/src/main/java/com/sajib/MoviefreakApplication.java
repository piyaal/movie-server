package com.sajib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviefreakApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviefreakApplication.class, args);
	}

}
